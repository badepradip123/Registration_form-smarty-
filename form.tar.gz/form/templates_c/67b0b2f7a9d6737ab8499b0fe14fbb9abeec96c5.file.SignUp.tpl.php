<?php /* Smarty version Smarty-3.1.13, created on 2017-09-20 11:22:41
         compiled from "./templates/SignUp.tpl" */ ?>
<?php /*%%SmartyHeaderCode:140073656459bb7c514ffe61-08263869%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '67b0b2f7a9d6737ab8499b0fe14fbb9abeec96c5' => 
    array (
      0 => './templates/SignUp.tpl',
      1 => 1505886727,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '140073656459bb7c514ffe61-08263869',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59bb7c515db487_00093643',
  'variables' => 
  array (
    'header' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59bb7c515db487_00093643')) {function content_59bb7c515db487_00093643($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['header']->value;?>


	<div class="signup">


 <form class="form" name="my_form" method="post" action="signup.php" enctype="multipart/form-data">
 		
	<div class="container">
	<h2>Registration Form</h2>	
  	<label><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required/>
    
    <label><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required/>
    
    <label><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="email" required/>
    
    <label><b>Password</b></label>
    <input type="password" placeholder="Confirm Password" name="password" autocomplete="new-password" value=""  required />
     
    
    <label><b>Confirm-Password</b></label>
    <input type="password" placeholder="Enter Password" name="confirmpassword" autocomplete="new-password" value="" required />
    
     
     <div class="avatar"><label>Select your Image: </label><input type="file" name="image" accept="image/*" required /></div>
       <button type="submit"   value="submit"  style="background-color: #379f5d;" onClick="return validate()";>Register</button>
    </div>
    
</form>
</div>
	
<div class="login">


 <form class="form" method="post" action="login.php" enctype="multipart/form-data">

   <div class="container">
   	 	<h2>Login Form</h2>
    <label><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required/>

    <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required/>
        
    <button type="submit" style="background-color: #379f5d;" >LOGIN</button>
    <input type="checkbox"> Remember me
  </div>
  
</form>
</div>
<script>
	function validate()
{
var i;
var Username_str=document.my_form.username;
var Fstname_str=document.my_form.name;
var Passwd_str=document.my_form.password;
var cnfpasswd_str=document.my_form.confirmpassword;
var pass1 = document.my_form("password").value;
var pass2 = document.my_form("confirmpassword").value;

var a = document.my_form.phone.value;

if((Username_str.value==null)||(Username_str.value==""))
{
	alert("Enter Username name");
	return false;
}
 if((Fstname_str.value==null)||(Fstname_str.value==""))
{
	alert("Enter First name");
	return false;
}
if((Lstname_str.value==null)||(Lstname_str.value==""))
{
	alert("Enter Last name");
	return false;
}

 if((Passwd_str.value==null)||(Passwd_str.value==""))
{
	alert("Please fill the Password");
	return false;
}
if((cnfpasswd_str.value==null)||(cnfpasswd_str.value==""))
{
	alert("Please fill the confirm password");
	return false;
}
if (pass1 != pass2) {
            alert("Passwords Do not match");
            document.getElementById("pass1").style.borderColor = "#E34234";
            document.getElementById("pass2").style.borderColor = "#E34234";
        }
        else {
            alert("Passwords Match!!!");
        }


return true;

}
</script>
<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>