<?php /* Smarty version Smarty-3.1.13, created on 2017-09-15 11:57:42
         compiled from "./templates/SignUp_Form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:151016585659b0d9da629b76-96004839%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ab53b2f49b917a67ecc9699798d0c38f22b504a7' => 
    array (
      0 => './templates/SignUp_Form.tpl',
      1 => 1505455665,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '151016585659b0d9da629b76-96004839',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59b0d9da8a2a86_81547095',
  'variables' => 
  array (
    'header' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59b0d9da8a2a86_81547095')) {function content_59b0d9da8a2a86_81547095($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<body>
<div class="body-content">
  <div class="module">
    <h1>Create an account</h1>
    <form class="form" method="post" action="signup.php" enctype="multipart/form-data">
      <div class="alert alert-error"></div>
      <input type="text" placeholder="User Name" name="username" required />
      <input type="text" placeholder="Your Name" name="name" required />
      <input type="email" placeholder="Email" name="email" required />
      <input type="password" placeholder="Password" name="password" autocomplete="new-password" required />
      <input type="password" placeholder="Confirm Password" name="confirmpassword" autocomplete="new-password" required />
      <div class="avatar"><label>Select your avatar: </label><input type="file" name="image" accept="image/*" required /></div>
      <input type="submit" value="Register" name="register" class="btn btn-block btn-primary" />
    </form>
  </div>
</div>
<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>