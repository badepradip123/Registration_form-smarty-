<?php /* Smarty version Smarty-3.1.13, created on 2017-09-15 18:24:30
         compiled from "./templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:144129068459b0d9d95de4d9-92436793%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97c13ae6868bbc459509c9f1b968154acd23eecc' => 
    array (
      0 => './templates/header.tpl',
      1 => 1505480065,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '144129068459b0d9d95de4d9-92436793',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59b0d9da2eaa59_85120526',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59b0d9da2eaa59_85120526')) {function content_59b0d9da2eaa59_85120526($_smarty_tpl) {?><!DOCTYPE html5>
<html>
<head>
	<title>Form</title>

<link rel="stylesheet" href="styles/signUp.css" type="text/css">
<link rel="stylesheet" href="styles/profile.css" type="text/css">

</head>
<body><?php }} ?>