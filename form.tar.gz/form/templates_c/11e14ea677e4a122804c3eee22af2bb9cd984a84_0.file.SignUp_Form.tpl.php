<?php
/* Smarty version 3.1.30, created on 2017-09-06 17:08:33
  from "/var/www/html/triyama/form/templates/SignUp_Form.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59afde39470694_19287633',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11e14ea677e4a122804c3eee22af2bb9cd984a84' => 
    array (
      0 => '/var/www/html/triyama/form/templates/SignUp_Form.tpl',
      1 => 1504697869,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59afde39470694_19287633 (Smarty_Internal_Template $_smarty_tpl) {
ob_start();
echo $_smarty_tpl->tpl_vars['header']->value;
$_prefixVariable1=ob_get_clean();
echo $_prefixVariable1;?>

<body>
<div class="body-content">
  <div class="module">
    <h1>Create an account</h1>
    <form class="form" action="signup.php" method="post" enctype="multipart/form-data" autocomplete="off">
      <div class="alert alert-error"></div>
      <input type="text" placeholder="User Name" name="username" required />
      <input type="email" placeholder="Email" name="email" required />
      <input type="password" placeholder="Password" name="password" autocomplete="new-password" required />
      <input type="password" placeholder="Confirm Password" name="confirmpassword" autocomplete="new-password" required />
      <div class="avatar"><label>Select your avatar: </label><input type="file" name="avatar"  required /></div>
      <input type="submit" value="Register" name="register" class="btn btn-block btn-primary" />
    </form>
  </div>
</div>
<?php ob_start();
echo $_smarty_tpl->tpl_vars['footer']->value;
$_prefixVariable2=ob_get_clean();
echo $_prefixVariable2;?>

<?php }
}
