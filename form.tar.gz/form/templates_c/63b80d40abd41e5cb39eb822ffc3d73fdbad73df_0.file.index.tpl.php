<?php
/* Smarty version 3.1.30, created on 2017-09-06 13:10:34
  from "/var/www/html/triyama/form/templates/index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59afa672511a76_61677572',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '63b80d40abd41e5cb39eb822ffc3d73fdbad73df' => 
    array (
      0 => '/var/www/html/triyama/form/templates/index.tpl',
      1 => 1504682649,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59afa672511a76_61677572 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_capitalize')) require_once '/var/www/html/scripts/libs/plugins/modifier.capitalize.php';
?>
<!DOCTYPE html>
<html>
	<head>
		<title><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</title>
	</head>
	<body>
		<h1><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</h1>
		User Information:<p>
		Name: <?php echo smarty_modifier_capitalize($_smarty_tpl->tpl_vars['name']->value);?>
<br>
	</body>
</html><?php }
}
