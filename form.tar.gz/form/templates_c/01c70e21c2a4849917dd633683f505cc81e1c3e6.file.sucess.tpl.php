<?php /* Smarty version Smarty-3.1.13, created on 2017-09-16 13:11:15
         compiled from "./templates/sucess.tpl" */ ?>
<?php /*%%SmartyHeaderCode:77523514359b8c39995d020-33539176%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '01c70e21c2a4849917dd633683f505cc81e1c3e6' => 
    array (
      0 => './templates/sucess.tpl',
      1 => 1505547663,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '77523514359b8c39995d020-33539176',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_59b8c3999ed9a1_74606608',
  'variables' => 
  array (
    'header' => 0,
    'username' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59b8c3999ed9a1_74606608')) {function content_59b8c3999ed9a1_74606608($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<h1><?php echo $_smarty_tpl->tpl_vars['username']->value;?>
 is sucessful register</h1>
<form class="form" method="post" action="logout.php" enctype="multipart/form-data">

<style>
body {background-color: #FFFFFF;}

</style>
<h2 style="text-align:center">User Profile Card</h2>

<div class="card">
  <img src="<?php echo $_SESSION['image'];?>
" alt="<?php echo $_SESSION['name'];?>
" style="width:100%">
  <h1><?php echo $_SESSION['name'];?>
</h1>
  <p class="title"><?php echo $_SESSION['email'];?>
</p>
  <p>Triyama Company</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
 </div>
 <p><button>Contact</button></p>
</div>
<div class="hyper">
	<a href="/triyama/form/">Logout</a>
</div>
</form>


<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>