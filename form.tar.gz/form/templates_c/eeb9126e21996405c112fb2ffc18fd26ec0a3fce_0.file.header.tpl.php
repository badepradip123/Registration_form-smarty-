<?php
/* Smarty version 3.1.30, created on 2017-09-06 15:51:22
  from "/var/www/html/triyama/form/templates/header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59afcc22aadb93_98048906',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eeb9126e21996405c112fb2ffc18fd26ec0a3fce' => 
    array (
      0 => '/var/www/html/triyama/form/templates/header.tpl',
      1 => 1504693279,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59afcc22aadb93_98048906 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html5>
<html>
<head>
	<title>Form</title>
<link href="//db.onlinewebfonts.com/c/a4e256ed67403c6ad5d43937ed48a77b?family=Core+Sans+N+W01+35+Light" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="form.css" type="text/css">
</head>
<body><?php }
}
