<?php
/* Smarty version 3.1.30, created on 2017-09-06 15:23:03
  from "/var/www/html/triyama/form/templates/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_59afc57fcb4314_12324058',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '639a7538c891b65fdea5b67bc2bbd2cef530cd09' => 
    array (
      0 => '/var/www/html/triyama/form/templates/footer.tpl',
      1 => 1504689086,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59afc57fcb4314_12324058 (Smarty_Internal_Template $_smarty_tpl) {
?>
</body>
</html><?php }
}
