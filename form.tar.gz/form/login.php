<?php

//require 'signup.php';
ini_set('display_errors', 'on');
error_reporting(E_ALL);
include 'configs/config.php';
include 'content/smarty.php';


//require 'templates/SignUp_Form.tpl';
//require 'index.php';

opendb();


if($_SERVER['REQUEST_METHOD'] === 'POST') {


					$username = $_POST['username'];
					$password = $_POST['password'];
				
     
				$sql = "SELECT * FROM signup where Username= '$username' && Password = '$password'";
				$stmt = $conn->prepare($sql);
				$stmt->execute();
				//$row = $stmt->fetchAll();
             
				$stmt = $conn->prepare($sql);
				 $stmt->execute();
                if ($stmt->rowCount() > 0){
                   
                	
					session_start();
					//$username = $_SESSION['username'];
					 //$name = 	$_SESSION['name'];
					       $_SESSION['username'] = $username;
							//$_SESSION['name'] = $name;
							//$_SESSION['image'] = $target;
							//$_SESSION['email'] = $email;
					//$smarty = new FORMSmarty();
					$smarty = new Smarty;
					$smarty->assign('header', $smarty->fetch('header.tpl'));
					$smarty->assign('footer', $smarty->fetch('footer.tpl'));
                    $smarty->assign('username',$username);
                    
					//$smarty->assign('result',$sth);
					$smarty->display('sucess.tpl');
                    
                }
				else{
   						echo "<script type = 'text/javascript'>";
							echo "alert('Username or Password does not match pleade Fill Form again')";
							echo "</script>";			
							$smarty = new Smarty();
							$smarty->assign('header', $smarty->fetch('header.tpl'));
							$smarty->assign('footer', $smarty->fetch('footer.tpl'));
							$smarty->display('SignUp.tpl');;
					}
                	
              
        
        } 

closedb();
?>
