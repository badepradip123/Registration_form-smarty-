<?php
	require_once(SMARTY_DIR . 'Smarty.class.php');

	class FORMSmarty extends Smarty
	{
		function FORMSmarty()
		{
		    $this->Smarty();

			$this->template_dir = SMARTY_ROOT . 'templates/';
			$this->compile_dir  = SMARTY_ROOT . 'templates_c/';
			$this->config_dir   = SMARTY_ROOT . 'configs/';
			$this->cache_dir    = SMARTY_ROOT . 'cache/';
		}
	}
?>