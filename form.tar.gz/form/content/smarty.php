<?php
ini_set('display_errors', 'on');
error_reporting(E_ALL);

define('SMARTY_ROOT', str_replace("\\","/",getcwd()) . "/");
define('SCRIPTS_DIR', str_replace("/triyama/form/document", "", $_SERVER['DOCUMENT_ROOT']) . "/scripts/");
define('SMARTY_DIR', SCRIPTS_DIR . "smarty.new/");
require_once(SCRIPTS_DIR . 'FORMSmarty.class.new.php');
//$smarty = new Smarty();

?>
