<?php

include 'configs/config.php';
include 'smarty.php';

//require 'templates/SignUp_Form.tpl';
//require 'index.php';
//echo "hii";
opendb();

ini_set('display_errors', 'on');
error_reporting(E_ALL);

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    
	global $conn,$smarty;
	$target = "";
	$image = "";
    if ($_POST['password'] == $_POST['confirmpassword']) {
    	
        $username = $_POST['username'];
		$name    =  $_POST['name'];
        $email = $_POST['email'];

        //md5 hash password for security
        $password = $_POST['password'];
		$confirmpasswd = $_POST['confirmpassword'];

        //path were our avatar image will be stored
        $target = "images/".basename($_FILES['image']['name']);
		$image = $_FILES['image']['name'];
            
            //copy image to images/ folder 
            if (copy($_FILES['image']['tmp_name'], $target)){
                //echo "hii";
                //set session variables to display on welcome page
                session_start();
                $_SESSION['username'] = $username;
				$_SESSION['name'] = $name;
				$_SESSION['image'] = $target;
				$_SESSION['email'] = $email;
				
				 $sql = "SELECT Username FROM signup where Username='$username'";
				 $stmt = $conn->prepare($sql);
				 $stmt->execute();
                if ($stmt->rowCount() > 0) {
                	echo "<script type = 'text/javascript'>";
					echo "alert('$username is already exists Please Fill another Username')";
					echo "</script>";
					$smarty = new Smarty();
					$smarty->assign('header', $smarty->fetch('header.tpl'));
					$smarty->assign('footer', $smarty->fetch('footer.tpl'));
					$smarty->display('SignUp.tpl');
                    
                }
				else{
   				$sql = "INSERT INTO signup (Username,Name, Email, Password,Image) VALUES ('$username','$name','$email', '$password','$image')";
                
                	$conn->exec($sql);
    				
	        		$smarty = new Smarty();
					$smarty->assign('header', $smarty->fetch('header.tpl'));
					$smarty->assign('footer', $smarty->fetch('footer.tpl'));
                    $smarty->assign('username',$username);
                    $smarty->assign('image',$image);
					//$smarty->assign('result',$sth);
					$smarty->display('sucess.tpl');
				
					$sth = $conn->prepare("SELECT * FROM signup where Username='$username'");
					$sth->execute();

					while($row = $sth->fetchAll()){
    	
					//$result[] =  $row['Email'];
	 				//echo "hii";
					}
				}
			}
		}
				
                	
                            
        
        else {
		echo "<script type = 'text/javascript'>";
		echo "alert('Password does not match pleade Fill Form again')";
		echo "</script>";			
		$smarty = new Smarty();
		$smarty->assign('header', $smarty->fetch('header.tpl'));
		$smarty->assign('footer', $smarty->fetch('footer.tpl'));
		$smarty->display('SignUp.tpl');
	
		}
					
    }


closedb();
?>
