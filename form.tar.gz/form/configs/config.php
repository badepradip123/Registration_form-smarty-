<?php
ini_set('display_errors', 'on');
error_reporting(E_ALL);

		$dbhost = 'localhost';
		$dbuser = 'root';
		$dbpass = 'tr1yama';
		$dbname = 'form';
		$conn = null;
function opendb()
		{
			global $dbhost, $dbuser, $dbpass, $dbname, $conn, $session;

			
			
				try {
					
					$conn = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
					$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
					$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
					$conn->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
					$conn->exec("SET session time_zone = '" . date('P') . "';");
					$conn->exec("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");
					$conn->exec("SET @@GLOBAL.sql_mode= 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';");
					$conn->exec("SET @@SESSION.sql_mode= 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';");
					//echo "sucess";die;
					//header("location: signup.php");
				} catch(PDOException $e) {
    				db_fail($e->getMessage());
				}
			}
	
		
function closedb()
		{
			global $conn;
			if($conn)
				$conn = null;
		}
	//$CONFIG_radio = true;
		?>