<?php
ini_set('display_errors', 'on');
error_reporting(E_ALL);
/*define('SMARTY_DIR', '/home/pradip/Downloads/smarty-3.1.30/libs/');
require_once(SMARTY_DIR . 'Smarty.class.php');
$smarty = new Smarty();
$smarty->template_dir = '/var/www/html/triyama/form/templates/';
$smarty->compile_dir  = '/var/www/html/triyama/form/templates_c/';
$smarty->config_dir   = '/var/www/html/triyama/form/configs/';
$smarty->cache_dir    = '/var/www/html/triyama/form/cache/';*/
require 'content/smarty.php';
$smarty = new Smarty();
//$smarty->assign('name','Ned');
$smarty->assign('header', $smarty->fetch('header.tpl'));
$smarty->assign('footer', $smarty->fetch('footer.tpl'));
$smarty->display('SignUp.tpl');


?>