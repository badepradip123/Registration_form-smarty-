<?php /* Smarty version 2.6.19, created on 2017-09-06 12:04:40
         compiled from index.tpl */ ?>
<html>
	<head>
		<title>{$name}</title>
	</head>
	<body>
		<h1>{$name}</h1>
		Name: {$name|capitalize}<br>
	</body>
</html>